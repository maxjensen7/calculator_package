# Simple Calculator

This is a simple calculator. It allows the user to do binary and unary operators based on their input.